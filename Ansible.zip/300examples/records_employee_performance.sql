INSERT  INTO employee_performance (employee_id, review_period, performance_score, manager_comments, goals_set, goals_achieved)
VALUES (20, 'Q2 2023', 71.78, 'Performance review for employee 1', 'Goals set for employee 1', 'Goals achieved by employee 1') ON CONFLICT DO NOTHING;
INSERT  INTO employee_performance (employee_id, review_period, performance_score, manager_comments, goals_set, goals_achieved)
VALUES (39, 'Q4 2021', 62.5, 'Performance review for employee 2', 'Goals set for employee 2', 'Goals achieved by employee 2') ON CONFLICT DO NOTHING;
INSERT  INTO employee_performance (employee_id, review_period, performance_score, manager_comments, goals_set, goals_achieved)
VALUES (2, 'Q3 2021', 86.44, 'Performance review for employee 3', 'Goals set for employee 3', 'Goals achieved by employee 3') ON CONFLICT DO NOTHING;
INSERT  INTO employee_performance (employee_id, review_period, performance_score, manager_comments, goals_set, goals_achieved)
VALUES (36, 'Q4 2022', 72.43, 'Performance review for employee 4', 'Goals set for employee 4', 'Goals achieved by employee 4') ON CONFLICT DO NOTHING;
INSERT  INTO employee_performance (employee_id, review_period, performance_score, manager_comments, goals_set, goals_achieved)
VALUES (14, 'Q2 2023', 80.57, 'Performance review for employee 5', 'Goals set for employee 5', 'Goals achieved by employee 5') ON CONFLICT DO NOTHING;
INSERT  INTO employee_performance (employee_id, review_period, performance_score, manager_comments, goals_set, goals_achieved)
VALUES (6, 'Q4 2021', 82.48, 'Performance review for employee 6', 'Goals set for employee 6', 'Goals achieved by employee 6') ON CONFLICT DO NOTHING;
INSERT  INTO employee_performance (employee_id, review_period, performance_score, manager_comments, goals_set, goals_achieved)
VALUES (28, 'Q1 2023', 65.22, 'Performance review for employee 7', 'Goals set for employee 7', 'Goals achieved by employee 7') ON CONFLICT DO NOTHING;
INSERT  INTO employee_performance (employee_id, review_period, performance_score, manager_comments, goals_set, goals_achieved)
VALUES (5, 'Q2 2023', 82.5, 'Performance review for employee 8', 'Goals set for employee 8', 'Goals achieved by employee 8') ON CONFLICT DO NOTHING;
INSERT  INTO employee_performance (employee_id, review_period, performance_score, manager_comments, goals_set, goals_achieved)
VALUES (10, 'Q2 2022', 62.36, 'Performance review for employee 9', 'Goals set for employee 9', 'Goals achieved by employee 9') ON CONFLICT DO NOTHING;
INSERT  INTO employee_performance (employee_id, review_period, performance_score, manager_comments, goals_set, goals_achieved)
VALUES (45, 'Q2 2020', 64.65, 'Performance review for employee 10', 'Goals set for employee 10', 'Goals achieved by employee 10') ON CONFLICT DO NOTHING;
INSERT  INTO employee_performance (employee_id, review_period, performance_score, manager_comments, goals_set, goals_achieved)
VALUES (7, 'Q3 2020', 99.93, 'Performance review for employee 11', 'Goals set for employee 11', 'Goals achieved by employee 11') ON CONFLICT DO NOTHING;
INSERT  INTO employee_performance (employee_id, review_period, performance_score, manager_comments, goals_set, goals_achieved)
VALUES (1, 'Q4 2024', 99.25, 'Performance review for employee 12', 'Goals set for employee 12', 'Goals achieved by employee 12') ON CONFLICT DO NOTHING;
INSERT  INTO employee_performance (employee_id, review_period, performance_score, manager_comments, goals_set, goals_achieved)
VALUES (3, 'Q3 2024', 82.36, 'Performance review for employee 13', 'Goals set for employee 13', 'Goals achieved by employee 13') ON CONFLICT DO NOTHING;
INSERT  INTO employee_performance (employee_id, review_period, performance_score, manager_comments, goals_set, goals_achieved)
VALUES (14, 'Q3 2020', 89.13, 'Performance review for employee 14', 'Goals set for employee 14', 'Goals achieved by employee 14') ON CONFLICT DO NOTHING;
INSERT  INTO employee_performance (employee_id, review_period, performance_score, manager_comments, goals_set, goals_achieved)
VALUES (23, 'Q4 2021', 83.41, 'Performance review for employee 15', 'Goals set for employee 15', 'Goals achieved by employee 15') ON CONFLICT DO NOTHING;
INSERT  INTO employee_performance (employee_id, review_period, performance_score, manager_comments, goals_set, goals_achieved)
VALUES (35, 'Q3 2024', 75.63, 'Performance review for employee 16', 'Goals set for employee 16', 'Goals achieved by employee 16') ON CONFLICT DO NOTHING;
INSERT  INTO employee_performance (employee_id, review_period, performance_score, manager_comments, goals_set, goals_achieved)
VALUES (50, 'Q3 2024', 88.33, 'Performance review for employee 17', 'Goals set for employee 17', 'Goals achieved by employee 17') ON CONFLICT DO NOTHING;
INSERT  INTO employee_performance (employee_id, review_period, performance_score, manager_comments, goals_set, goals_achieved)
VALUES (26, 'Q3 2023', 70.5, 'Performance review for employee 18', 'Goals set for employee 18', 'Goals achieved by employee 18') ON CONFLICT DO NOTHING;
INSERT  INTO employee_performance (employee_id, review_period, performance_score, manager_comments, goals_set, goals_achieved)
VALUES (16, 'Q4 2021', 90.06, 'Performance review for employee 19', 'Goals set for employee 19', 'Goals achieved by employee 19') ON CONFLICT DO NOTHING;
INSERT  INTO employee_performance (employee_id, review_period, performance_score, manager_comments, goals_set, goals_achieved)
VALUES (43, 'Q2 2021', 80.73, 'Performance review for employee 20', 'Goals set for employee 20', 'Goals achieved by employee 20') ON CONFLICT DO NOTHING;
INSERT  INTO employee_performance (employee_id, review_period, performance_score, manager_comments, goals_set, goals_achieved)
VALUES (1, 'Q4 2023', 72.21, 'Performance review for employee 21', 'Goals set for employee 21', 'Goals achieved by employee 21') ON CONFLICT DO NOTHING;
INSERT  INTO employee_performance (employee_id, review_period, performance_score, manager_comments, goals_set, goals_achieved)
VALUES (34, 'Q3 2023', 90.11, 'Performance review for employee 22', 'Goals set for employee 22', 'Goals achieved by employee 22') ON CONFLICT DO NOTHING;
INSERT  INTO employee_performance (employee_id, review_period, performance_score, manager_comments, goals_set, goals_achieved)
VALUES (5, 'Q4 2023', 77.97, 'Performance review for employee 23', 'Goals set for employee 23', 'Goals achieved by employee 23') ON CONFLICT DO NOTHING;
INSERT  INTO employee_performance (employee_id, review_period, performance_score, manager_comments, goals_set, goals_achieved)
VALUES (11, 'Q3 2020', 79.91, 'Performance review for employee 24', 'Goals set for employee 24', 'Goals achieved by employee 24') ON CONFLICT DO NOTHING;
INSERT  INTO employee_performance (employee_id, review_period, performance_score, manager_comments, goals_set, goals_achieved)
VALUES (50, 'Q4 2022', 74.42, 'Performance review for employee 25', 'Goals set for employee 25', 'Goals achieved by employee 25') ON CONFLICT DO NOTHING;
INSERT  INTO employee_performance (employee_id, review_period, performance_score, manager_comments, goals_set, goals_achieved)
VALUES (9, 'Q4 2024', 85.08, 'Performance review for employee 26', 'Goals set for employee 26', 'Goals achieved by employee 26') ON CONFLICT DO NOTHING;
INSERT  INTO employee_performance (employee_id, review_period, performance_score, manager_comments, goals_set, goals_achieved)
VALUES (43, 'Q2 2024', 63.69, 'Performance review for employee 27', 'Goals set for employee 27', 'Goals achieved by employee 27') ON CONFLICT DO NOTHING;
INSERT  INTO employee_performance (employee_id, review_period, performance_score, manager_comments, goals_set, goals_achieved)
VALUES (45, 'Q2 2023', 61.78, 'Performance review for employee 28', 'Goals set for employee 28', 'Goals achieved by employee 28') ON CONFLICT DO NOTHING;
INSERT  INTO employee_performance (employee_id, review_period, performance_score, manager_comments, goals_set, goals_achieved)
VALUES (10, 'Q4 2022', 75.11, 'Performance review for employee 29', 'Goals set for employee 29', 'Goals achieved by employee 29') ON CONFLICT DO NOTHING;
INSERT  INTO employee_performance (employee_id, review_period, performance_score, manager_comments, goals_set, goals_achieved)
VALUES (17, 'Q4 2022', 86.05, 'Performance review for employee 30', 'Goals set for employee 30', 'Goals achieved by employee 30') ON CONFLICT DO NOTHING;
INSERT  INTO employee_performance (employee_id, review_period, performance_score, manager_comments, goals_set, goals_achieved)
VALUES (43, 'Q2 2022', 86.45, 'Performance review for employee 31', 'Goals set for employee 31', 'Goals achieved by employee 31') ON CONFLICT DO NOTHING;
INSERT  INTO employee_performance (employee_id, review_period, performance_score, manager_comments, goals_set, goals_achieved)
VALUES (19, 'Q1 2024', 63.25, 'Performance review for employee 32', 'Goals set for employee 32', 'Goals achieved by employee 32') ON CONFLICT DO NOTHING;
INSERT  INTO employee_performance (employee_id, review_period, performance_score, manager_comments, goals_set, goals_achieved)
VALUES (43, 'Q1 2021', 60.21, 'Performance review for employee 33', 'Goals set for employee 33', 'Goals achieved by employee 33') ON CONFLICT DO NOTHING;
INSERT  INTO employee_performance (employee_id, review_period, performance_score, manager_comments, goals_set, goals_achieved)
VALUES (37, 'Q3 2022', 99.81, 'Performance review for employee 34', 'Goals set for employee 34', 'Goals achieved by employee 34') ON CONFLICT DO NOTHING;
INSERT  INTO employee_performance (employee_id, review_period, performance_score, manager_comments, goals_set, goals_achieved)
VALUES (50, 'Q3 2022', 87.81, 'Performance review for employee 35', 'Goals set for employee 35', 'Goals achieved by employee 35') ON CONFLICT DO NOTHING;
INSERT  INTO employee_performance (employee_id, review_period, performance_score, manager_comments, goals_set, goals_achieved)
VALUES (34, 'Q4 2020', 65.78, 'Performance review for employee 36', 'Goals set for employee 36', 'Goals achieved by employee 36') ON CONFLICT DO NOTHING;
INSERT  INTO employee_performance (employee_id, review_period, performance_score, manager_comments, goals_set, goals_achieved)
VALUES (40, 'Q2 2023', 73.25, 'Performance review for employee 37', 'Goals set for employee 37', 'Goals achieved by employee 37') ON CONFLICT DO NOTHING;
INSERT  INTO employee_performance (employee_id, review_period, performance_score, manager_comments, goals_set, goals_achieved)
VALUES (15, 'Q2 2022', 92.57, 'Performance review for employee 38', 'Goals set for employee 38', 'Goals achieved by employee 38') ON CONFLICT DO NOTHING;
INSERT  INTO employee_performance (employee_id, review_period, performance_score, manager_comments, goals_set, goals_achieved)
VALUES (44, 'Q3 2020', 75.22, 'Performance review for employee 39', 'Goals set for employee 39', 'Goals achieved by employee 39') ON CONFLICT DO NOTHING;
INSERT  INTO employee_performance (employee_id, review_period, performance_score, manager_comments, goals_set, goals_achieved)
VALUES (9, 'Q2 2024', 62.35, 'Performance review for employee 40', 'Goals set for employee 40', 'Goals achieved by employee 40') ON CONFLICT DO NOTHING;
INSERT  INTO employee_performance (employee_id, review_period, performance_score, manager_comments, goals_set, goals_achieved)
VALUES (4, 'Q1 2022', 68.83, 'Performance review for employee 41', 'Goals set for employee 41', 'Goals achieved by employee 41') ON CONFLICT DO NOTHING;
INSERT  INTO employee_performance (employee_id, review_period, performance_score, manager_comments, goals_set, goals_achieved)
VALUES (5, 'Q4 2020', 74.76, 'Performance review for employee 42', 'Goals set for employee 42', 'Goals achieved by employee 42') ON CONFLICT DO NOTHING;
INSERT  INTO employee_performance (employee_id, review_period, performance_score, manager_comments, goals_set, goals_achieved)
VALUES (22, 'Q2 2023', 68.36, 'Performance review for employee 43', 'Goals set for employee 43', 'Goals achieved by employee 43') ON CONFLICT DO NOTHING;
INSERT  INTO employee_performance (employee_id, review_period, performance_score, manager_comments, goals_set, goals_achieved)
VALUES (48, 'Q3 2024', 67.33, 'Performance review for employee 44', 'Goals set for employee 44', 'Goals achieved by employee 44') ON CONFLICT DO NOTHING;
INSERT  INTO employee_performance (employee_id, review_period, performance_score, manager_comments, goals_set, goals_achieved)
VALUES (19, 'Q3 2021', 69.6, 'Performance review for employee 45', 'Goals set for employee 45', 'Goals achieved by employee 45') ON CONFLICT DO NOTHING;
INSERT  INTO employee_performance (employee_id, review_period, performance_score, manager_comments, goals_set, goals_achieved)
VALUES (34, 'Q3 2023', 91.74, 'Performance review for employee 46', 'Goals set for employee 46', 'Goals achieved by employee 46') ON CONFLICT DO NOTHING;
INSERT  INTO employee_performance (employee_id, review_period, performance_score, manager_comments, goals_set, goals_achieved)
VALUES (12, 'Q4 2024', 80.86, 'Performance review for employee 47', 'Goals set for employee 47', 'Goals achieved by employee 47') ON CONFLICT DO NOTHING;
INSERT  INTO employee_performance (employee_id, review_period, performance_score, manager_comments, goals_set, goals_achieved)
VALUES (9, 'Q4 2020', 69.84, 'Performance review for employee 48', 'Goals set for employee 48', 'Goals achieved by employee 48') ON CONFLICT DO NOTHING;
INSERT  INTO employee_performance (employee_id, review_period, performance_score, manager_comments, goals_set, goals_achieved)
VALUES (1, 'Q4 2020', 60.31, 'Performance review for employee 49', 'Goals set for employee 49', 'Goals achieved by employee 49') ON CONFLICT DO NOTHING;
INSERT  INTO employee_performance (employee_id, review_period, performance_score, manager_comments, goals_set, goals_achieved)
VALUES (43, 'Q2 2021', 98.81, 'Performance review for employee 50', 'Goals set for employee 50', 'Goals achieved by employee 50') ON CONFLICT DO NOTHING;
INSERT  INTO employee_performance (employee_id, review_period, performance_score, manager_comments, goals_set, goals_achieved)
VALUES (31, 'Q1 2022', 85.98, 'Performance review for employee 51', 'Goals set for employee 51', 'Goals achieved by employee 51') ON CONFLICT DO NOTHING;
INSERT  INTO employee_performance (employee_id, review_period, performance_score, manager_comments, goals_set, goals_achieved)
VALUES (11, 'Q1 2023', 92.29, 'Performance review for employee 52', 'Goals set for employee 52', 'Goals achieved by employee 52') ON CONFLICT DO NOTHING;
INSERT  INTO employee_performance (employee_id, review_period, performance_score, manager_comments, goals_set, goals_achieved)
VALUES (8, 'Q2 2024', 63.24, 'Performance review for employee 53', 'Goals set for employee 53', 'Goals achieved by employee 53') ON CONFLICT DO NOTHING;
INSERT  INTO employee_performance (employee_id, review_period, performance_score, manager_comments, goals_set, goals_achieved)
VALUES (2, 'Q4 2022', 94.67, 'Performance review for employee 54', 'Goals set for employee 54', 'Goals achieved by employee 54') ON CONFLICT DO NOTHING;
INSERT  INTO employee_performance (employee_id, review_period, performance_score, manager_comments, goals_set, goals_achieved)
VALUES (35, 'Q4 2024', 96.92, 'Performance review for employee 55', 'Goals set for employee 55', 'Goals achieved by employee 55') ON CONFLICT DO NOTHING;
INSERT  INTO employee_performance (employee_id, review_period, performance_score, manager_comments, goals_set, goals_achieved)
VALUES (14, 'Q4 2021', 60.38, 'Performance review for employee 56', 'Goals set for employee 56', 'Goals achieved by employee 56') ON CONFLICT DO NOTHING;
INSERT  INTO employee_performance (employee_id, review_period, performance_score, manager_comments, goals_set, goals_achieved)
VALUES (14, 'Q3 2022', 62.05, 'Performance review for employee 57', 'Goals set for employee 57', 'Goals achieved by employee 57') ON CONFLICT DO NOTHING;
INSERT  INTO employee_performance (employee_id, review_period, performance_score, manager_comments, goals_set, goals_achieved)
VALUES (36, 'Q3 2021', 60.95, 'Performance review for employee 58', 'Goals set for employee 58', 'Goals achieved by employee 58') ON CONFLICT DO NOTHING;
INSERT  INTO employee_performance (employee_id, review_period, performance_score, manager_comments, goals_set, goals_achieved)
VALUES (37, 'Q4 2021', 76.41, 'Performance review for employee 59', 'Goals set for employee 59', 'Goals achieved by employee 59') ON CONFLICT DO NOTHING;
INSERT  INTO employee_performance (employee_id, review_period, performance_score, manager_comments, goals_set, goals_achieved)
VALUES (45, 'Q4 2022', 86.74, 'Performance review for employee 60', 'Goals set for employee 60', 'Goals achieved by employee 60') ON CONFLICT DO NOTHING;
INSERT  INTO employee_performance (employee_id, review_period, performance_score, manager_comments, goals_set, goals_achieved)
VALUES (46, 'Q2 2023', 71.03, 'Performance review for employee 61', 'Goals set for employee 61', 'Goals achieved by employee 61') ON CONFLICT DO NOTHING;
INSERT  INTO employee_performance (employee_id, review_period, performance_score, manager_comments, goals_set, goals_achieved)
VALUES (19, 'Q3 2020', 80.41, 'Performance review for employee 62', 'Goals set for employee 62', 'Goals achieved by employee 62') ON CONFLICT DO NOTHING;
INSERT  INTO employee_performance (employee_id, review_period, performance_score, manager_comments, goals_set, goals_achieved)
VALUES (17, 'Q2 2020', 89.04, 'Performance review for employee 63', 'Goals set for employee 63', 'Goals achieved by employee 63') ON CONFLICT DO NOTHING;
INSERT  INTO employee_performance (employee_id, review_period, performance_score, manager_comments, goals_set, goals_achieved)
VALUES (34, 'Q3 2023', 74.09, 'Performance review for employee 64', 'Goals set for employee 64', 'Goals achieved by employee 64') ON CONFLICT DO NOTHING;
INSERT  INTO employee_performance (employee_id, review_period, performance_score, manager_comments, goals_set, goals_achieved)
VALUES (49, 'Q4 2021', 90.22, 'Performance review for employee 65', 'Goals set for employee 65', 'Goals achieved by employee 65') ON CONFLICT DO NOTHING;
INSERT  INTO employee_performance (employee_id, review_period, performance_score, manager_comments, goals_set, goals_achieved)
VALUES (23, 'Q2 2024', 96.99, 'Performance review for employee 66', 'Goals set for employee 66', 'Goals achieved by employee 66') ON CONFLICT DO NOTHING;
INSERT  INTO employee_performance (employee_id, review_period, performance_score, manager_comments, goals_set, goals_achieved)
VALUES (37, 'Q4 2020', 66.38, 'Performance review for employee 67', 'Goals set for employee 67', 'Goals achieved by employee 67') ON CONFLICT DO NOTHING;
INSERT  INTO employee_performance (employee_id, review_period, performance_score, manager_comments, goals_set, goals_achieved)
VALUES (14, 'Q2 2022', 96.47, 'Performance review for employee 68', 'Goals set for employee 68', 'Goals achieved by employee 68') ON CONFLICT DO NOTHING;
INSERT  INTO employee_performance (employee_id, review_period, performance_score, manager_comments, goals_set, goals_achieved)
VALUES (35, 'Q3 2021', 75.61, 'Performance review for employee 69', 'Goals set for employee 69', 'Goals achieved by employee 69') ON CONFLICT DO NOTHING;
INSERT  INTO employee_performance (employee_id, review_period, performance_score, manager_comments, goals_set, goals_achieved)
VALUES (49, 'Q3 2022', 83.43, 'Performance review for employee 70', 'Goals set for employee 70', 'Goals achieved by employee 70') ON CONFLICT DO NOTHING;
INSERT  INTO employee_performance (employee_id, review_period, performance_score, manager_comments, goals_set, goals_achieved)
VALUES (2, 'Q4 2022', 67.23, 'Performance review for employee 71', 'Goals set for employee 71', 'Goals achieved by employee 71') ON CONFLICT DO NOTHING;
INSERT  INTO employee_performance (employee_id, review_period, performance_score, manager_comments, goals_set, goals_achieved)
VALUES (42, 'Q4 2023', 69.9, 'Performance review for employee 72', 'Goals set for employee 72', 'Goals achieved by employee 72') ON CONFLICT DO NOTHING;
INSERT  INTO employee_performance (employee_id, review_period, performance_score, manager_comments, goals_set, goals_achieved)
VALUES (38, 'Q4 2023', 89.19, 'Performance review for employee 73', 'Goals set for employee 73', 'Goals achieved by employee 73') ON CONFLICT DO NOTHING;
INSERT  INTO employee_performance (employee_id, review_period, performance_score, manager_comments, goals_set, goals_achieved)
VALUES (2, 'Q4 2023', 92.15, 'Performance review for employee 74', 'Goals set for employee 74', 'Goals achieved by employee 74') ON CONFLICT DO NOTHING;
INSERT  INTO employee_performance (employee_id, review_period, performance_score, manager_comments, goals_set, goals_achieved)
VALUES (18, 'Q4 2022', 79.37, 'Performance review for employee 75', 'Goals set for employee 75', 'Goals achieved by employee 75') ON CONFLICT DO NOTHING;
INSERT  INTO employee_performance (employee_id, review_period, performance_score, manager_comments, goals_set, goals_achieved)
VALUES (15, 'Q3 2024', 92.66, 'Performance review for employee 76', 'Goals set for employee 76', 'Goals achieved by employee 76') ON CONFLICT DO NOTHING;
INSERT  INTO employee_performance (employee_id, review_period, performance_score, manager_comments, goals_set, goals_achieved)
VALUES (49, 'Q1 2024', 95.16, 'Performance review for employee 77', 'Goals set for employee 77', 'Goals achieved by employee 77') ON CONFLICT DO NOTHING;
INSERT  INTO employee_performance (employee_id, review_period, performance_score, manager_comments, goals_set, goals_achieved)
VALUES (29, 'Q2 2024', 95.21, 'Performance review for employee 78', 'Goals set for employee 78', 'Goals achieved by employee 78') ON CONFLICT DO NOTHING;
INSERT  INTO employee_performance (employee_id, review_period, performance_score, manager_comments, goals_set, goals_achieved)
VALUES (44, 'Q2 2021', 79.56, 'Performance review for employee 79', 'Goals set for employee 79', 'Goals achieved by employee 79') ON CONFLICT DO NOTHING;
INSERT  INTO employee_performance (employee_id, review_period, performance_score, manager_comments, goals_set, goals_achieved)
VALUES (18, 'Q2 2020', 60.84, 'Performance review for employee 80', 'Goals set for employee 80', 'Goals achieved by employee 80') ON CONFLICT DO NOTHING;
INSERT  INTO employee_performance (employee_id, review_period, performance_score, manager_comments, goals_set, goals_achieved)
VALUES (8, 'Q3 2024', 81.89, 'Performance review for employee 81', 'Goals set for employee 81', 'Goals achieved by employee 81') ON CONFLICT DO NOTHING;
INSERT  INTO employee_performance (employee_id, review_period, performance_score, manager_comments, goals_set, goals_achieved)
VALUES (26, 'Q2 2023', 84.26, 'Performance review for employee 82', 'Goals set for employee 82', 'Goals achieved by employee 82') ON CONFLICT DO NOTHING;
INSERT  INTO employee_performance (employee_id, review_period, performance_score, manager_comments, goals_set, goals_achieved)
VALUES (50, 'Q4 2023', 97.28, 'Performance review for employee 83', 'Goals set for employee 83', 'Goals achieved by employee 83') ON CONFLICT DO NOTHING;
INSERT  INTO employee_performance (employee_id, review_period, performance_score, manager_comments, goals_set, goals_achieved)
VALUES (9, 'Q3 2023', 98.23, 'Performance review for employee 84', 'Goals set for employee 84', 'Goals achieved by employee 84') ON CONFLICT DO NOTHING;
INSERT  INTO employee_performance (employee_id, review_period, performance_score, manager_comments, goals_set, goals_achieved)
VALUES (23, 'Q4 2020', 88.12, 'Performance review for employee 85', 'Goals set for employee 85', 'Goals achieved by employee 85') ON CONFLICT DO NOTHING;
INSERT  INTO employee_performance (employee_id, review_period, performance_score, manager_comments, goals_set, goals_achieved)
VALUES (3, 'Q2 2021', 96.62, 'Performance review for employee 86', 'Goals set for employee 86', 'Goals achieved by employee 86') ON CONFLICT DO NOTHING;
INSERT  INTO employee_performance (employee_id, review_period, performance_score, manager_comments, goals_set, goals_achieved)
VALUES (30, 'Q4 2022', 79.98, 'Performance review for employee 87', 'Goals set for employee 87', 'Goals achieved by employee 87') ON CONFLICT DO NOTHING;
INSERT  INTO employee_performance (employee_id, review_period, performance_score, manager_comments, goals_set, goals_achieved)
VALUES (32, 'Q2 2023', 87.96, 'Performance review for employee 88', 'Goals set for employee 88', 'Goals achieved by employee 88') ON CONFLICT DO NOTHING;
INSERT  INTO employee_performance (employee_id, review_period, performance_score, manager_comments, goals_set, goals_achieved)
VALUES (50, 'Q3 2021', 98.25, 'Performance review for employee 89', 'Goals set for employee 89', 'Goals achieved by employee 89') ON CONFLICT DO NOTHING;
INSERT  INTO employee_performance (employee_id, review_period, performance_score, manager_comments, goals_set, goals_achieved)
VALUES (20, 'Q3 2024', 73.64, 'Performance review for employee 90', 'Goals set for employee 90', 'Goals achieved by employee 90') ON CONFLICT DO NOTHING;
INSERT  INTO employee_performance (employee_id, review_period, performance_score, manager_comments, goals_set, goals_achieved)
VALUES (18, 'Q1 2020', 83.19, 'Performance review for employee 91', 'Goals set for employee 91', 'Goals achieved by employee 91') ON CONFLICT DO NOTHING;
INSERT  INTO employee_performance (employee_id, review_period, performance_score, manager_comments, goals_set, goals_achieved)
VALUES (1, 'Q4 2021', 79.98, 'Performance review for employee 92', 'Goals set for employee 92', 'Goals achieved by employee 92') ON CONFLICT DO NOTHING;
INSERT  INTO employee_performance (employee_id, review_period, performance_score, manager_comments, goals_set, goals_achieved)
VALUES (27, 'Q3 2024', 64.6, 'Performance review for employee 93', 'Goals set for employee 93', 'Goals achieved by employee 93') ON CONFLICT DO NOTHING;
INSERT  INTO employee_performance (employee_id, review_period, performance_score, manager_comments, goals_set, goals_achieved)
VALUES (26, 'Q1 2021', 71.51, 'Performance review for employee 94', 'Goals set for employee 94', 'Goals achieved by employee 94') ON CONFLICT DO NOTHING;
INSERT  INTO employee_performance (employee_id, review_period, performance_score, manager_comments, goals_set, goals_achieved)
VALUES (47, 'Q3 2023', 80.3, 'Performance review for employee 95', 'Goals set for employee 95', 'Goals achieved by employee 95') ON CONFLICT DO NOTHING;
INSERT  INTO employee_performance (employee_id, review_period, performance_score, manager_comments, goals_set, goals_achieved)
VALUES (48, 'Q1 2020', 71.76, 'Performance review for employee 96', 'Goals set for employee 96', 'Goals achieved by employee 96') ON CONFLICT DO NOTHING;
INSERT  INTO employee_performance (employee_id, review_period, performance_score, manager_comments, goals_set, goals_achieved)
VALUES (28, 'Q3 2021', 90.54, 'Performance review for employee 97', 'Goals set for employee 97', 'Goals achieved by employee 97') ON CONFLICT DO NOTHING;
INSERT  INTO employee_performance (employee_id, review_period, performance_score, manager_comments, goals_set, goals_achieved)
VALUES (45, 'Q4 2022', 79.16, 'Performance review for employee 98', 'Goals set for employee 98', 'Goals achieved by employee 98') ON CONFLICT DO NOTHING;
INSERT  INTO employee_performance (employee_id, review_period, performance_score, manager_comments, goals_set, goals_achieved)
VALUES (35, 'Q3 2020', 89.35, 'Performance review for employee 99', 'Goals set for employee 99', 'Goals achieved by employee 99') ON CONFLICT DO NOTHING;
INSERT  INTO employee_performance (employee_id, review_period, performance_score, manager_comments, goals_set, goals_achieved)
VALUES (45, 'Q2 2022', 70.6, 'Performance review for employee 100', 'Goals set for employee 100', 'Goals achieved by employee 100') ON CONFLICT DO NOTHING;
