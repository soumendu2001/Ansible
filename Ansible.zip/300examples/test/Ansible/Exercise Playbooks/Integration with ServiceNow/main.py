from flask import Flask, request, jsonify
from collections import OrderedDict
import subprocess
import re

app = Flask(__name__)

def parse_kill_output(stdout, incident_id):
    match= re.search(r"Killed Process (\S+) with PID (\d+)",stdout)
    killed_pid = match.group(2) if match else "N/A"
    killed_pname = match.group(1) if match else "N/A"
    return{
            "Incident ID": incident_id,
            "Killed PID": killed_pid,
            "Killed Process name": killed_pname,
            "Status":"Top CPU consuming process is terminated"
            }


def parse_device_health(stdout, incident_id):
    # Extract host summary
    host_summary_match = re.search(
        r'PLAY RECAP \*+\n(.+?) : ok=(\d+)\s+changed=(\d+)\s+unreachable=(\d+)\s+failed=(\d+)', stdout)
    host_summary = {
        "host": host_summary_match.group(1).strip(),
        "tasks_ok": host_summary_match.group(2),
        "tasks_changed": host_summary_match.group(3),
        "tasks_unreachable": host_summary_match.group(4),
        "tasks_failed": host_summary_match.group(5)
    } if host_summary_match else {}

    # Extract Stress-ng process info
    stress_proc_match = re.search(r'"stress_check\.stdout":\s*"(.+?)"', stdout)
    stress_process = stress_proc_match.group(1).replace("\\n", "\n") if stress_proc_match else "N/A"

    # Extract CPU usage
    cpu_usage_match = re.search(r'"msg":\s*"([^"]*%Cpu\(s\):[^"]*)"', stdout)
    if cpu_usage_match:
        cpu_line = cpu_usage_match.group(1)
        cpu_idle_match = re.search(r'(\d+\.\d+)\s+id', cpu_line)
        cpu_idle = cpu_idle_match.group(1) if cpu_idle_match else "N/A"
        cpu_usage = str(round(100 - float(cpu_idle), 2)) + "%" if cpu_idle != "N/A" else "N/A"
    else:
        cpu_usage = "N/A"

    # Extract Memory Usage Info
    mem_process_match = re.search(r'"msg":\s*"([^"]*Mem:[^"]*)"', stdout)
    mem_process = mem_process_match.group(1).replace("\\n", "\n") if mem_process_match else "N/A"

    # Extract Uptime info
    uptime_info_match = re.search(r'"msg":\s*"([^"]*load average:[^"]*)"', stdout)
    uptime_info = uptime_info_match.group(1).replace("\\n", "\n") if uptime_info_match else "N/A"

    # Extract Disk Usage info
    #disk_info_match = re.search(r'"msg":\s*"Filesystem[^"]*)"',stdout)
    disk_info_match = re.search(r'"msg":\s*"([^"]*Filesystem[^"]*)"', stdout)

    disk_info = disk_info_match.group(1).replace("\\n","\n") if disk_info_match else "N/A"

    # Formatted output
    formatted_output = "\n".join([
        f"Host: {host_summary.get('host', 'N/A')}",
        f"Tasks OK: {host_summary.get('tasks_ok', 'N/A')}",
        f"Tasks Changed: {host_summary.get('tasks_changed', 'N/A')}",
        f"Tasks Failed: {host_summary.get('tasks_failed', 'N/A')}",
        f"Tasks Unreachable: {host_summary.get('tasks_unreachable', 'N/A')}",
        f"CPU Usage: {cpu_usage}",
        f"Memory Usage: {mem_process}",
        f"Disk Usage: { disk_info}",
        f"Uptime: {uptime_info}",
        f"Stress Process: {stress_process}"
    ])

    return {
        "Incident ID": incident_id,
        "Status": "Playbook executed successfully",
        "Host Summary": host_summary,
        "Output": formatted_output
    }

def run_playbook(playbook,targets, incident_id, parser_func):
    results=[]

    if not playbook or not targets:
        return jsonify({'error': 'Missing playbook or targets'}), 400

    
    for target in targets:
        host = target.get("host")
        user = target.get("user", "ubuntu")
        cmd = [
            "ansible-playbook",
            playbook,
            "-i", f"{host},",
            "-u", user,
            "--private-key", "/home/ubuntu/.ssh/AnsibleLab.pem",
            "--ssh-extra-args", "-o StrictHostKeyChecking=no",
            "--extra-vars", f"target={host}"
        ]
        process = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        stdout, stderr = process.communicate()
        if process.returncode !=0:
            return jsonify({
                "Incident id": incident_id,
                "Status": "Playbook execution is failed",
                "Error": stderr.decode()
                }),500
        
        parsed = parser_func(stdout.decode(), incident_id)
        results.append(parsed)
    return jsonify(results)
        
def parse_cpu_output(stdout, incident_id):
    # Extract Hostname 
    host_summary_match = re.search(
        r'PLAY RECAP \*+\n(.+?) : ok=(\d+)\s+changed=(\d+)\s+unreachable=(\d+)\s+failed=(\d+)', stdout)
    host_summary = host_summary_match.group(1).strip()
    #Extract CPU Usage    
    #cpu_usage_match = re.search(r'"msg":\s*"([^"]*%Cpu\(s\):[^"]*)"', stdout)
    cpu_usage_match= re.search(r'%Cpu\(s\):.*?(\d+\.\d+)\s+id',stdout)
    if cpu_usage_match:
        #cpu_line = cpu_usage_match.group(1)
        #cpu_idle_match = re.search(r'(\d+\.\d+)\s+id', cpu_line)
        cpu_idle = cpu_usage_match.group(1) 
        cpu_usage = str(round(100 - float(cpu_idle), 2)) + "%" 
    else:
        cpu_usage = "N/A"
    return OrderedDict([
           ( "Incident ID", incident_id),
           ("Host Name", host_summary),
           ("CPU idle", cpu_idle),
           ( "CPU Usage", cpu_usage)
            ])

def parse_disk_output(stdout, incident_id):
    # Extract Hostname
    host_summary_match = re.search(
        r'PLAY RECAP \*+\n(.+?) : ok=(\d+)\s+changed=(\d+)\s+unreachable=(\d+)\s+failed=(\d+)', stdout)
    host_summary = host_summary_match.group(1).strip()
    

    # Extract Disk Usage info
    #disk_info_match = re.search(r'"msg":\s*"Filesystem[^"]*)"',stdout)
    disk_info_match = re.search(r'"msg":\s*"([^"]*Filesystem[^"]*)"', stdout)
    disk_info = disk_info_match.group(1).replace("\\n","\n") if disk_info_match else "N/A"

    return{
            "Incident ID": incident_id,
            "Host Summary": host_summary,
            "Disk Usage": disk_info
          }
def parse_mem_output(stdout, incident_id):

    # Extract Hostname
    host_summary_match = re.search(
        r'PLAY RECAP \*+\n(.+?) : ok=(\d+)\s+changed=(\d+)\s+unreachable=(\d+)\s+failed=(\d+)', stdout)
    host_summary = host_summary_match.group(1).strip()


    # Extract Memory Usage Info
    mem_process_match = re.search(r'"msg":\s*"([^"]*Mem:[^"]*)"', stdout)
    mem_process = mem_process_match.group(1).replace("\\n", "\n") if mem_process_match else "N/A"

    return {
            "Incident ID": incident_id,
            "Host Name": host_summary,
            "Memory Usage": mem_process
            }
def parse_uptime(stdout,incident_id):
    # Extract Hostname
    host_summary_match = re.search(
        r'PLAY RECAP \*+\n(.+?) : ok=(\d+)\s+changed=(\d+)\s+unreachable=(\d+)\s+failed=(\d+)', stdout)
    host_summary = host_summary_match.group(1).strip()

    # Extract Uptime info
    uptime_info_match = re.search(r'"msg":\s*"([^"]*load average:[^"]*)"', stdout)
    uptime_info = uptime_info_match.group(1).replace("\\n", "\n") if uptime_info_match else "N/A"

    return{
            "Incident ID": incident_id,
            "Host Name": host_summary,
            "Device Uptime": uptime_info
          }
def parse_service(stdout, incident_id):
    #Extract Host information
    host_summary_match = re.search(
            r'PLAY RECAP \*+\n(.+?) : ok=(\d+)\s+changed=(\d+)\s+unreachable=(\d+)\s+failed=(\d+)', stdout)
    host_summary = host_summary_match.group(1).strip()
    #Extract Service Name
    service_info_match = re.search(r'"msg":\s*"([^"]+)"', stdout)
    service_info = service_info_match.group(1).replace("\\n","\n") if service_info_match else "N/A"
    running = []
    running_count=0
    not_running_count=0
    not_running = []
    for line in service_info.split('\n'):
        if any(state in line for state in ['dead','failed','inactive','exited']):
               line.replace('\u25cf', '').strip()
               not_running.append(line)
               not_running_count = not_running_count+1
        else:
               line.replace('\u25cf', '').strip()
               running.append(line)
               running_count = running_count+1
    

    return{
            "Incident ID": incident_id,
            "Host Name": host_summary,
            "Not Running Service Status": not_running,
            "Running Services": running,
            "Total Count of Services": not_running_count + running_count,
            "Count of Not Running Services": not_running_count,
            "Count of Running Services": running_count
          }

@app.route('/api/cpuusage', methods=['POST'])
def cpu_usage():
    data= request.get_json()
    if not data or 'playbook'not in data or 'targets' not in data:
        return jsonify({"Error": "Missing Required Fields"}), 400
   
    return run_playbook(data['playbook'],data['targets'], data.get('incident','N/A'), parse_cpu_output)

@app.route('/api/killcpu', methods=['POST'])
def kill_cpu_process():
    data = request.get_json()
    if not data or 'playbook' not in data or 'targets' not in data:
        return jsonify({"Error": "Missing Required Fields"})
    return run_playbook(data['playbook'], data['targets'], data.get('incident','N/A'), parse_kill_output)

@app.route('/api/memusage', methods=['POST'])
def mem_usage():
    data = request.get_json()
    if not data or 'playbook' not in data or 'targets' not in data:
        return jsonify({"Error": "Missing Required Fields"}), 400
    else:
        return run_playbook(data['playbook'],data['targets'],data.get('incident','N/A'), parse_mem_output)

@app.route('/api/servicestatus', methods=['POST'])
def service_status():
    data = request.get_json()
    if not data or 'playbook' not in data or 'targets' not in data:
        return jsonify({"Error":"Missing Required details "}),400
    else:
        return run_playbook(data['playbook'], data['targets'], data.get('incident','N/A'), parse_service)

@app.route('/api/diskusage', methods=['POST'])
def disk_usage():
    data = request.get_json()
    if not data or 'playbook' not in data or 'targets' not in data:
        return jsonify({"Error": "Missing Required Fields"}), 400
    else:
        return run_playbook(data['playbook'],data['targets'],data.get('incident','N/A'), parse_disk_output)

@app.route('/api/devicehealth', methods=['POST'])
def devicehealth():
    data = request.get_json()
    if not data or 'playbook' not in data or 'targets' not in data:
        return jsonify({"Error": "Missing Required Fields"}), 400
    else:
        return run_playbook(data['playbook'],data['targets'],data.get('incident','N/A'), parse_device_health)

@app.route('/api/uptime', methods=['POST'])
def uptime():
    data = request.get_json()
    if not data or 'playbook' not in data or 'targets' not in data:
        return jsonify({"Error": "Missing Required Fields"}), 400
    else:
        return run_playbook(data['playbook'],data['targets'],data.get('incident','N/A'), parse_uptime)

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)

