#!/bin/bash
brew --version
brew search ansible
brew install ansible
ansible --version
