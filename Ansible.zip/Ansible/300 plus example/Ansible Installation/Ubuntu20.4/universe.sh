#!/bin/bash
sudo apt update
sudo apt install ansible
